package com.web.common.exception;

public class BadAccessException extends RuntimeException{
	
	public BadAccessException(String msg) {
		super(msg);
	}
}
