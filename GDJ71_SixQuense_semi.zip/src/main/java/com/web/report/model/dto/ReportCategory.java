package com.web.report.model.dto;

public class ReportCategory {
	private int reportCategoryNo;
	private String reportCategory;
	private String reportContent;
}
