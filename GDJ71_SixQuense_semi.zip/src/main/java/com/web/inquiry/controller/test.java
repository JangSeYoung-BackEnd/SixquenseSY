package com.web.inquiry.controller;

public class test {

}
