package com.web.report.model.dto;

import java.lang.reflect.Member;
import java.sql.Date;



public class ReportBoard {
	private Date reportTime;
	private String reportContent;
	private String reportStatus;
	private int accompanyNo;
	private int reportCategoryNo;
	private String reportCategoryType;
	private String reportCategoryContent;
	private int reportLevel;
	private int memberNo;
}
