package com.web.member.controller;

public class MemberGmailApi {

}
