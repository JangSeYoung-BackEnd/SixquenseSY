package com.web.product.dto;

public class ProductreviewattachmentDto {
	private String ReviewOriFilename;
	private String ReviewRenameFilename;
	private int AttachmentNo;
	private int CommentNo;
	
}
